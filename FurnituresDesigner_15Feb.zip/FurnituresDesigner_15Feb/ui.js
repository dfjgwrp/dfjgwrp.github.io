

document.getElementById("closeVerticalSection1_1").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_1_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_1_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1_4").src="icons/close.png";
};





document.getElementById("DoorLeft_S1").onmouseover = function() { 
    document.getElementById("DoorLeft_S1").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S1").onmouseout = function() {
    document.getElementById("DoorLeft_S1").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S1").onmouseover = function() { 
    document.getElementById("DoorRight_S1").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S1").onmouseout = function() {
    document.getElementById("DoorRight_S1").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S1").onmouseover = function() { 
    document.getElementById("DoubleDoor_S1").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S1").onmouseout = function() {
    document.getElementById("DoubleDoor_S1").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S1").onmouseover = function() { 
    document.getElementById("Drawer_S1").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S1").onmouseout = function() {
    document.getElementById("Drawer_S1").src="icons/Drawer_Close.jpg";
};



document.getElementById("DoorLeft_S2").onmouseover = function() { 
    document.getElementById("DoorLeft_S2").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S2").onmouseout = function() {
    document.getElementById("DoorLeft_S2").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S2").onmouseover = function() { 
    document.getElementById("DoorRight_S2").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S2").onmouseout = function() {
    document.getElementById("DoorRight_S2").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S2").onmouseover = function() { 
    document.getElementById("DoubleDoor_S2").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S2").onmouseout = function() {
    document.getElementById("DoubleDoor_S2").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S2").onmouseover = function() { 
    document.getElementById("Drawer_S2").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S2").onmouseout = function() {
    document.getElementById("Drawer_S2").src="icons/Drawer_Close.jpg";
};



document.getElementById("DoorLeft_S3_1").onmouseover = function() { 
    document.getElementById("DoorLeft_S3_1").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S3_1").onmouseout = function() {
    document.getElementById("DoorLeft_S3_1").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S3_1").onmouseover = function() { 
    document.getElementById("DoorRight_S3_1").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S3_1").onmouseout = function() {
    document.getElementById("DoorRight_S3_1").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S3_1").onmouseover = function() { 
    document.getElementById("DoubleDoor_S3_1").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S3_1").onmouseout = function() {
    document.getElementById("DoubleDoor_S3_1").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S3_1").onmouseover = function() { 
    document.getElementById("Drawer_S3_1").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S3_1").onmouseout = function() {
    document.getElementById("Drawer_S3_1").src="icons/Drawer_Close.jpg";
};


document.getElementById("DoorLeft_S4_1").onmouseover = function() { 
    document.getElementById("DoorLeft_S4_1").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S4_1").onmouseout = function() {
    document.getElementById("DoorLeft_S4_1").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S4_1").onmouseover = function() { 
    document.getElementById("DoorRight_S4_1").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S4_1").onmouseout = function() {
    document.getElementById("DoorRight_S4_1").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S4_1").onmouseover = function() { 
    document.getElementById("DoubleDoor_S4_1").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S4_1").onmouseout = function() {
    document.getElementById("DoubleDoor_S4_1").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S4_1").onmouseover = function() { 
    document.getElementById("Drawer_S4_1").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S4_1").onmouseout = function() {
    document.getElementById("Drawer_S4_1").src="icons/Drawer_Close.jpg";
};


/* 
function openInternalShelving_S1() {
    var checkBox_HorizontalPartition_S1 = document.getElementById("InternalShelving_S1");

    if (checkBox_HorizontalPartition_S1.checked == true) {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "flex";
        document.getElementById("Drawer_S1").style.pointerEvents = "none";
        document.getElementById("Drawer_Section1").style.pointerEvents = "none";
        document.getElementById("Drawer_S1").src="icons/Drawer_Disable.jpg";
        
    } 
    else {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "none";
    }
} */



/* function openInternalShelving_S1_1_2() {
    var checkBox_HorizontalPartition_S1_1 = document.getElementById("InternalShelving_S1_1_2");

    if (checkBox_HorizontalPartition_S1_1_2.checked == true) {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "flex";
        document.getElementById("Drawer_S1").style.pointerEvents = "none";
        document.getElementById("Drawer_Section1").style.pointerEvents = "none";
        document.getElementById("Drawer_S1").src="icons/Drawer_Disable.jpg";
        
    } 
    else {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "none";
    }
}
 */